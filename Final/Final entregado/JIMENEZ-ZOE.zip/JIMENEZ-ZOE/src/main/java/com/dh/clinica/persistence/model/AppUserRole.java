package com.dh.clinica.persistence.model;

public enum AppUserRole {
    USER,ADMIN
}
