package com.dh.clinica.service;

public enum AppUserRoleService {
    USER,ADMIN
}
